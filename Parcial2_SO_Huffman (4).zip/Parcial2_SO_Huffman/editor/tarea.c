/*
 * tarea.c - Tarea de compresion/descompresion en segundo plano del editor.
 *
 * Hilos involucrados:
 *   - Hilo principal (UI): dibuja la pantalla y lee el teclado. Nunca se
 *     bloquea esperando a la tarea; espera eventos con poll() sobre
 *     STDIN y el extremo de lectura del pipe de notificacion.
 *   - Hilo coordinador de la tarea: toma el candado del archivo (si aplica),
 *     llama a huf_comprimir()/huf_descomprimir() (que crea el pool de
 *     trabajadores y el escritor), suelta el candado y avisa por el pipe.
 *
 * Estado compartido UI <-> coordinador: la estructura T (protegida por T.m),
 * el progreso (protegido por prog.mutex, ver huffman_concurrente.c) y el candado
 * lectores-escritores del archivo del editor.
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include "tarea.h"
#include "huffman_concurrente.h"

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define CANDADO_NINGUNO   0
#define CANDADO_LECTURA   1
#define CANDADO_ESCRITURA 2

static struct {
    pthread_mutex_t m;
    pthread_cond_t cond_arranque;  /* handshake: el coordinador ya tomo el candado */
    int activa;                    /* hay un hilo coordinador sin join */
    int terminada;                 /* el coordinador ya termino su trabajo */
    int candado_listo;
    int modo_candado;
    int hay_resultado;             /* hay un resultado para mostrar en la barra */
    int recarga_pendiente;
    TipoTareaBG tipo;
    char origen[PATH_MAX];
    char destino[PATH_MAX];
    HufOpciones op;
    int rc;
    char err[256];
    HufResultado res;
    double t_inicio, t_fin;
    pthread_t hilo;
} T = { .m = PTHREAD_MUTEX_INITIALIZER, .cond_arranque = PTHREAD_COND_INITIALIZER };

static HufProgreso prog;
static int prog_iniciado = 0;

/* Candado lectores-escritores sobre el archivo abierto en el editor. */
static pthread_rwlock_t candado_archivo = PTHREAD_RWLOCK_INITIALIZER;

static int pipe_fd[2] = { -1, -1 };
static volatile sig_atomic_t senal_recibida = 0;

static double ahora(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

/* Despierta al hilo principal. write() de 1 byte en un pipe NO bloqueante:
 * nunca detiene a un trabajador (si el pipe esta lleno, ya hay un aviso
 * pendiente y basta con ese). Es async-signal-safe: se usa tambien desde
 * el manejador de senales. */
static void notificar_ui(void *ctx) {
    (void)ctx;
    if (pipe_fd[1] >= 0) {
        int errno_prev = errno;
        ssize_t r = write(pipe_fd[1], "n", 1);
        (void)r;
        errno = errno_prev;
    }
}

static void manejador_senal(int signo) {
    senal_recibida = signo;
    notificar_ui(NULL);
}

int tarea_inicializar(void) {
    if (pipe_fd[0] != -1) return 0;
    if (pipe2(pipe_fd, O_NONBLOCK | O_CLOEXEC) == -1) return -1;

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = manejador_senal;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGHUP, &sa, NULL);
    signal(SIGPIPE, SIG_IGN);
    return 0;
}

int tarea_fd_notificacion(void) { return pipe_fd[0]; }

int tarea_activa(void) {
    pthread_mutex_lock(&T.m);
    int a = T.activa;
    pthread_mutex_unlock(&T.m);
    return a;
}

/* ---------------------------------------------------------------------------
 * Hilo coordinador de la tarea
 * ------------------------------------------------------------------------- */
static void *hilo_coordinador(void *arg) {
    (void)arg;
    pthread_setname_np(pthread_self(), "huf-coordinador");
    /* origen/destino/op/modo se escribieron ANTES de pthread_create y no
     * cambian mientras la tarea este activa: se leen sin carrera. */
    int modo = T.modo_candado;
    if (modo == CANDADO_LECTURA) pthread_rwlock_rdlock(&candado_archivo);
    else if (modo == CANDADO_ESCRITURA) pthread_rwlock_wrlock(&candado_archivo);

    pthread_mutex_lock(&T.m);
    T.candado_listo = 1;
    pthread_cond_signal(&T.cond_arranque);
    pthread_mutex_unlock(&T.m);

    char err[256] = "";
    HufResultado res;
    memset(&res, 0, sizeof(res));
    int rc = (T.tipo == TAREA_COMPRIMIR)
        ? huf_comprimir(T.origen, T.destino, &T.op, &prog, &res, err, sizeof(err))
        : huf_descomprimir(T.origen, T.destino, &T.op, &prog, &res, err, sizeof(err));

    /* El resultado (y sobre todo 'recarga_pendiente') se publica ANTES de
     * soltar el candado del archivo. Asi, si el hilo principal logra tomar
     * el candado, ya ve con certeza que debe recargar el archivo, y nunca
     * puede guardar su buffer viejo encima del archivo recien descomprimido. */
    pthread_mutex_lock(&T.m);
    T.rc = rc;
    snprintf(T.err, sizeof(T.err), "%s", err);
    T.res = res;
    T.t_fin = ahora();
    T.terminada = 1;
    if (rc == HUF_OK && modo == CANDADO_ESCRITURA) T.recarga_pendiente = 1;
    pthread_mutex_unlock(&T.m);

    if (modo != CANDADO_NINGUNO) pthread_rwlock_unlock(&candado_archivo);

    notificar_ui(NULL);   /* el hilo principal hara el pthread_join */
    return NULL;
}

/* ---------------------------------------------------------------------------
 * API para el hilo principal
 * ------------------------------------------------------------------------- */
static int mismo_archivo(const char *a, const char *b) {
    if (!a || !b) return 0;
    struct stat sa, sb;
    if (stat(a, &sa) == 0 && stat(b, &sb) == 0) return sa.st_dev == sb.st_dev && sa.st_ino == sb.st_ino;
    return strcmp(a, b) == 0;
}

static unsigned long env_ulong(const char *nombre, unsigned long defecto) {
    const char *v = getenv(nombre);
    if (!v || !*v) return defecto;
    char *fin; unsigned long n = strtoul(v, &fin, 10);
    return (*fin == '\0') ? n : defecto;
}

int tarea_lanzar(TipoTareaBG tipo, const char *origen, const char *destino,
                 const char *archivo_editor, char *msg, size_t msglen) {
    if (tarea_activa()) {
        snprintf(msg, msglen, "Ya hay una tarea en segundo plano en curso (use 't' para ver su estado o 'c' para cancelarla).");
        return -1;
    }
    if (strlen(origen) >= PATH_MAX || strlen(destino) >= PATH_MAX) {
        snprintf(msg, msglen, "Ruta demasiado larga."); return -1;
    }

    /* Que candado necesita la tarea sobre el archivo del editor:
     *   - si LEE el archivo del editor  -> lectura (el editor puede seguir leyendo)
     *   - si lo REEMPLAZA               -> escritura (exclusivo) */
    int modo = CANDADO_NINGUNO;
    if (mismo_archivo(origen, archivo_editor)) modo = CANDADO_LECTURA;
    if (mismo_archivo(destino, archivo_editor)) modo = CANDADO_ESCRITURA;

    /* No hay ningun hilo de una tarea previa vivo: es seguro reiniciar el progreso. */
    if (prog_iniciado) huf_progreso_destruir(&prog);
    huf_progreso_init(&prog, notificar_ui, NULL);
    prog_iniciado = 1;

    pthread_mutex_lock(&T.m);
    T.tipo = tipo;
    snprintf(T.origen, sizeof(T.origen), "%s", origen);
    snprintf(T.destino, sizeof(T.destino), "%s", destino);
    T.op.hilos = (int)env_ulong("EAFIT_HUF_HILOS", 0);
    T.op.tam_bloque = (size_t)env_ulong("EAFIT_HUF_BLOQUE", 0);
    T.op.retardo_ms = (unsigned)env_ulong("EAFIT_HUF_RETARDO_MS", 0);
    T.modo_candado = modo;
    T.activa = 1;
    T.terminada = 0;
    T.candado_listo = 0;
    T.hay_resultado = 0;
    T.recarga_pendiente = 0;
    T.err[0] = '\0';
    T.t_inicio = ahora();
    pthread_mutex_unlock(&T.m);

    /* El coordinador (y por herencia sus trabajadores) nace con todas las
     * senales bloqueadas: solo el hilo principal atiende senales. */
    sigset_t todas, previa;
    sigfillset(&todas);
    pthread_sigmask(SIG_BLOCK, &todas, &previa);
    int r = pthread_create(&T.hilo, NULL, hilo_coordinador, NULL);
    pthread_sigmask(SIG_SETMASK, &previa, NULL);
    if (r != 0) {
        pthread_mutex_lock(&T.m);
        T.activa = 0;
        pthread_mutex_unlock(&T.m);
        snprintf(msg, msglen, "No se pudo crear el hilo de la tarea: %s", strerror(r));
        return -1;
    }

    /* Handshake: esperamos (microsegundos) a que el coordinador tenga el
     * candado ANTES de devolver el control al usuario. Asi es imposible que
     * el usuario alcance a guardar el archivo entre el lanzamiento y el
     * momento en que la tarea empieza a leerlo. No hay riesgo de bloqueo:
     * el hilo principal no tiene el candado tomado en este punto. */
    pthread_mutex_lock(&T.m);
    while (!T.candado_listo) pthread_cond_wait(&T.cond_arranque, &T.m);
    pthread_mutex_unlock(&T.m);

    snprintf(msg, msglen, "%s en segundo plano: %s -> %s%s",
             tipo == TAREA_COMPRIMIR ? "Comprimiendo" : "Descomprimiendo", origen, destino,
             modo == CANDADO_LECTURA ? " (el archivo queda en solo lectura mientras tanto)" :
             modo == CANDADO_ESCRITURA ? " (el archivo del editor queda bloqueado y se recargara al terminar)" : "");
    return 0;
}

int tarea_procesar_eventos(void) {
    int ev = 0;
    char basura[256];
    ssize_t n;
    while ((n = read(pipe_fd[0], basura, sizeof(basura))) > 0) ev |= EV_PROGRESO;
    if (senal_recibida) ev |= EV_SENAL;

    pthread_mutex_lock(&T.m);
    int unir = T.activa && T.terminada;
    pthread_mutex_unlock(&T.m);
    if (unir) {
        pthread_join(T.hilo, NULL);          /* el hilo ya termino: retorno inmediato */
        pthread_mutex_lock(&T.m);
        T.activa = 0;
        T.hay_resultado = 1;
        pthread_mutex_unlock(&T.m);
        ev |= EV_TERMINADA;
    }
    return ev;
}

void tarea_cancelar(void) {
    if (tarea_activa()) huf_progreso_cancelar(&prog);
}

void tarea_finalizar(void) {
    if (tarea_activa()) {
        huf_progreso_cancelar(&prog);
        pthread_join(T.hilo, NULL);
        pthread_mutex_lock(&T.m);
        T.activa = 0;
        pthread_mutex_unlock(&T.m);
    }
    if (prog_iniciado) { huf_progreso_destruir(&prog); prog_iniciado = 0; }
    if (pipe_fd[0] != -1) { close(pipe_fd[0]); close(pipe_fd[1]); pipe_fd[0] = pipe_fd[1] = -1; }
}

int tarea_consumir_recarga(void) {
    pthread_mutex_lock(&T.m);
    int r = T.recarga_pendiente;
    T.recarga_pendiente = 0;
    pthread_mutex_unlock(&T.m);
    return r;
}

/* ---------------------------------------------------------------------------
 * Textos para la interfaz
 * ------------------------------------------------------------------------- */
static const char *nombre_base(const char *ruta) {
    const char *b = strrchr(ruta, '/');
    return b ? b + 1 : ruta;
}

void tarea_texto_barra(char *buf, size_t n) {
    buf[0] = '\0';
    pthread_mutex_lock(&T.m);
    int activa = T.activa, terminada = T.terminada, hay = T.hay_resultado, rc = T.rc;
    TipoTareaBG tipo = T.tipo;
    char destino[64];
    snprintf(destino, sizeof(destino), "%.63s", nombre_base(T.destino));
    double ratio = T.res.tam_original ? 100.0 * (double)T.res.tam_comprimido / (double)T.res.tam_original : 0.0;
    pthread_mutex_unlock(&T.m);

    if (activa && !terminada) {
        int pct = 0;
        huf_progreso_leer(&prog, NULL, &pct, NULL, NULL);
        char barra[11];
        int llenos = pct / 10;
        for (int i = 0; i < 10; i++) barra[i] = i < llenos ? '#' : '-';
        barra[10] = '\0';
        snprintf(buf, n, " [%s %3d%% %s]", tipo == TAREA_COMPRIMIR ? "Comprimiendo" : "Descomprimiendo", pct, barra);
    } else if (hay) {
        if (rc == HUF_OK)
            snprintf(buf, n, " [%s OK: %s (%.1f%%)]", tipo == TAREA_COMPRIMIR ? "Compresion" : "Descompresion", destino, ratio);
        else if (rc == HUF_CANCELADO)
            snprintf(buf, n, " [Tarea cancelada]");
        else
            snprintf(buf, n, " [Error en la tarea: ver orden t]");
    }
}

void tarea_texto_detalle(char *buf, size_t n) {
    pthread_mutex_lock(&T.m);
    int activa = T.activa, terminada = T.terminada, hay = T.hay_resultado, rc = T.rc, modo = T.modo_candado;
    TipoTareaBG tipo = T.tipo;
    HufResultado res = T.res;
    double t = (activa && !terminada ? ahora() : T.t_fin) - T.t_inicio;
    char origen[PATH_MAX], destino[PATH_MAX], err[256];
    snprintf(origen, sizeof(origen), "%s", T.origen);
    snprintf(destino, sizeof(destino), "%s", T.destino);
    snprintf(err, sizeof(err), "%s", T.err);
    int hilos = T.op.hilos;
    pthread_mutex_unlock(&T.m);

    if (!activa && !hay) { snprintf(buf, n, "No hay ninguna tarea en segundo plano.\n"); return; }

    HufFase fase = HUF_FASE_INACTIVA; int pct = 0; unsigned long hechos = 0, total = 0;
    if (prog_iniciado) huf_progreso_leer(&prog, &fase, &pct, &hechos, &total);
    const char *estado = (activa && !terminada) ? "EN CURSO" :
                         rc == HUF_OK ? "TERMINADA CORRECTAMENTE" :
                         rc == HUF_CANCELADO ? "CANCELADA" : "TERMINADA CON ERROR";
    int off = snprintf(buf, n,
        "Tarea      : %s\n"
        "Estado     : %s\n"
        "Origen     : %s\n"
        "Destino    : %s\n"
        "Fase       : %s (%lu/%lu bloques)\n"
        "Progreso   : %d%%\n"
        "Tiempo     : %.2f s\n"
        "Hilos      : %s\n"
        "Candado    : %s\n",
        tipo == TAREA_COMPRIMIR ? "compresion Huffman" : "descompresion Huffman", estado,
        origen, destino, huf_nombre_fase(fase), hechos, total, pct, t,
        hilos > 0 ? "fijado por EAFIT_HUF_HILOS" : "uno por nucleo disponible",
        modo == CANDADO_LECTURA ? "lectura sobre el archivo del editor (no se puede modificar)" :
        modo == CANDADO_ESCRITURA ? "escritura sobre el archivo del editor (no se puede leer ni modificar)" :
        "ninguno (la tarea no toca el archivo del editor)");
    if (off < 0 || (size_t)off >= n) return;
    if (!(activa && !terminada) && rc == HUF_OK)
        snprintf(buf + off, n - (size_t)off, "Resultado  : %llu bytes originales, %llu comprimidos (%.1f%%), %u bloques, %d hilos\n",
                 (unsigned long long)res.tam_original, (unsigned long long)res.tam_comprimido,
                 res.tam_original ? 100.0 * (double)res.tam_comprimido / (double)res.tam_original : 0.0,
                 res.bloques, res.hilos);
    else if (!(activa && !terminada) && rc == HUF_ERROR)
        snprintf(buf + off, n - (size_t)off, "Error      : %s\n", err);
}

/* ---------------------------------------------------------------------------
 * Candado del archivo del editor (lado UI: SIEMPRE try, nunca bloquea)
 * ------------------------------------------------------------------------- */
static void mensaje_ocupado(char *msg, size_t msglen) {
    int pct = 0;
    if (prog_iniciado) huf_progreso_leer(&prog, NULL, &pct, NULL, NULL);
    pthread_mutex_lock(&T.m);
    TipoTareaBG tipo = T.tipo;
    pthread_mutex_unlock(&T.m);
    snprintf(msg, msglen, "Archivo ocupado: se esta %s en segundo plano (%d%%). Espere a que termine o cancele con la orden 'c'.",
             tipo == TAREA_COMPRIMIR ? "comprimiendo" : "descomprimiendo", pct);
}

int tarea_intentar_escribir_archivo(char *msg, size_t msglen) {
    int r = pthread_rwlock_trywrlock(&candado_archivo);
    if (r == 0) return 0;
    mensaje_ocupado(msg, msglen);
    return -1;
}

int tarea_intentar_leer_archivo(char *msg, size_t msglen) {
    int r = pthread_rwlock_tryrdlock(&candado_archivo);
    if (r == 0) return 0;
    mensaje_ocupado(msg, msglen);
    return -1;
}

void tarea_soltar_archivo(void) { pthread_rwlock_unlock(&candado_archivo); }

int tarea_archivo_ocupado(void) {
    pthread_mutex_lock(&T.m);
    int r = T.activa && !T.terminada && T.modo_candado != CANDADO_NINGUNO;
    pthread_mutex_unlock(&T.m);
    return r;
}
