#ifndef HUFFMAN_CONCURRENTE_H
#define HUFFMAN_CONCURRENTE_H

/*
 * Modulo: compresor / descompresor Huffman CONCURRENTE (Parcial 2).
 *
 * El archivo se divide en bloques (chunks) de tamano fijo que procesa un
 * pool de hilos trabajadores. El pipeline completo es:
 *
 *   COMPRESION
 *     Fase 1 (conteo)      : los trabajadores leen bloques con pread() y
 *                            cuentan frecuencias en un histograma LOCAL por
 *                            bloque (reduccion local); luego lo suman al
 *                            histograma global protegido por un mutex.
 *     Fase 2 (arbol)       : el hilo coordinador construye UN arbol global.
 *     Fase 3 (codificacion): los trabajadores codifican bloques en paralelo
 *                            y un hilo ESCRITOR los escribe en el archivo de
 *                            salida estrictamente en orden (0,1,2,...).
 *   DESCOMPRESION
 *     Mismo pipeline: los trabajadores decodifican bloques en paralelo
 *     (cada bloque guarda su tamano y su CRC32) y el escritor los ensambla
 *     en orden.
 *
 * Primitivas usadas: pthread_mutex, pthread_cond, semaforo POSIX (sem_t)
 * y pthread_once. Ninguna espera es activa (no hay busy waiting).
 */

#include <pthread.h>
#include <stddef.h>
#include <stdint.h>

/* Fases visibles desde la interfaz (barra de progreso). */
typedef enum {
    HUF_FASE_INACTIVA = 0,
    HUF_FASE_PREPARANDO,
    HUF_FASE_CONTEO,
    HUF_FASE_ARBOL,
    HUF_FASE_CODIFICACION,
    HUF_FASE_DECODIFICACION,
    HUF_FASE_FINALIZANDO,
    HUF_FASE_TERMINADA
} HufFase;

/* Progreso compartido entre el pipeline (escritores) y la interfaz
 * (lector). Todos los campos se leen/escriben con 'mutex' tomado. */
typedef struct HufProgreso {
    pthread_mutex_t mutex;
    HufFase fase;
    unsigned long bloques_hechos;   /* de la fase actual */
    unsigned long bloques_total;
    int porcentaje;                 /* 0..100 global */
    int cancelar;                   /* 1 = la interfaz pidio cancelar */
    struct Pipeline *activo;        /* pipeline en curso (para abortarlo) */

    /* Se invoca (sin locks tomados) cada vez que cambia el porcentaje o la
     * fase. Debe ser barata y no bloquear: el editor escribe 1 byte en un
     * pipe no bloqueante para despertar a su bucle principal. */
    void (*notificar)(void *ctx);
    void *ctx;
} HufProgreso;

typedef struct {
    int hilos;              /* trabajadores del pool (<=0 -> nucleos disponibles) */
    size_t tam_bloque;      /* bytes por bloque (0 -> HUF_BLOQUE_DEFECTO) */
    unsigned retardo_ms;    /* SOLO DEMO: pausa artificial por bloque (0 = ninguna) */
} HufOpciones;

typedef struct {
    uint64_t tam_original;
    uint64_t tam_comprimido;
    uint32_t bloques;
    int hilos;
} HufResultado;

#define HUF_BLOQUE_DEFECTO   (1u << 20)   /* 1 MiB */
#define HUF_HILOS_MAX        64

/* Valores de retorno */
#define HUF_OK          0
#define HUF_ERROR      -1
#define HUF_CANCELADO   1

void huf_progreso_init(HufProgreso *p, void (*notificar)(void *), void *ctx);
void huf_progreso_destruir(HufProgreso *p);
/* Pide cancelar la operacion en curso. No bloquea: despierta a todos los
 * hilos del pipeline para que terminen ordenadamente. */
void huf_progreso_cancelar(HufProgreso *p);
/* Copia consistente (snapshot) del progreso, tomada con el mutex. */
void huf_progreso_leer(HufProgreso *p, HufFase *fase, int *porcentaje,
                       unsigned long *hechos, unsigned long *total);
const char *huf_nombre_fase(HufFase f);

/* Comprime 'origen' en 'destino'. Escribe primero en un temporal y hace
 * rename() solo si todo salio bien (el destino nunca queda a medias). */
int huf_comprimir(const char *origen, const char *destino, const HufOpciones *op,
                  HufProgreso *prog, HufResultado *res, char *err, size_t errlen);

/* Descomprime 'origen' (.huf) en 'destino', verificando el CRC32 de cada bloque. */
int huf_descomprimir(const char *origen, const char *destino, const HufOpciones *op,
                     HufProgreso *prog, HufResultado *res, char *err, size_t errlen);

/* CRC32 (IEEE 802.3), tabla inicializada una sola vez con pthread_once. */
uint32_t huf_crc32(uint32_t crc, const unsigned char *buf, size_t len);

#endif /* HUFFMAN_CONCURRENTE_H */
