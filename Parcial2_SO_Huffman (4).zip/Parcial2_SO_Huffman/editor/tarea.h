#ifndef TAREA_H
#define TAREA_H

/*
 * Modulo: tarea en segundo plano (background worker) del editor.
 *
 * Conecta el compresor concurrente (huffman_concurrente.c) con el editor SIN congelar
 * la interfaz:
 *   - La compresion/descompresion corre en un hilo COORDINADOR propio (que a
 *     su vez crea el pool de trabajadores y el escritor).
 *   - El hilo principal (UI) nunca espera a la tarea: espera con poll() a
 *     que llegue una tecla O una notificacion por un pipe ("self-pipe"),
 *     asi la barra de progreso se redibuja en tiempo real sin espera activa.
 *   - El archivo abierto en el editor se protege con un candado
 *     lectores-escritores (pthread_rwlock). La tarea lo toma en modo lectura
 *     si LEE ese archivo (comprimirlo) o escritura si lo REEMPLAZA
 *     (descomprimir encima). El editor solo usa try-lock: si el archivo esta
 *     ocupado, la orden se rechaza con un mensaje en vez de bloquear la UI.
 */

#include <stddef.h>

typedef enum { TAREA_COMPRIMIR, TAREA_DESCOMPRIMIR } TipoTareaBG;

/* Bits que devuelve tarea_procesar_eventos() */
#define EV_PROGRESO  0x1   /* cambio el progreso: hay que redibujar */
#define EV_TERMINADA 0x2   /* la tarea termino y ya se hizo join */
#define EV_SENAL     0x4   /* llego SIGINT/SIGTERM/SIGHUP: salir limpio */

/* Crea el pipe de notificacion e instala los manejadores de senales. */
int  tarea_inicializar(void);
/* Descriptor que el bucle principal vigila con poll() junto a STDIN. */
int  tarea_fd_notificacion(void);
/* Vacia el pipe y, si la tarea termino, hace pthread_join (no bloquea de
 * forma apreciable: el hilo ya esta saliendo). */
int  tarea_procesar_eventos(void);

/* Lanza la tarea. 'archivo_editor' es el archivo abierto en el editor
 * (puede ser NULL) para decidir que candado tomar. Retorna 0 si arranco,
 * -1 con el motivo en 'msg' si no (p. ej. ya hay una tarea en curso). */
int  tarea_lanzar(TipoTareaBG tipo, const char *origen, const char *destino,
                  const char *archivo_editor, char *msg, size_t msglen);

int  tarea_activa(void);          /* 1 si hay una tarea en curso (aun no unida) */
void tarea_cancelar(void);        /* pide cancelar (no bloquea) */
void tarea_finalizar(void);       /* cancela + join: se usa al salir del editor */

/* Texto corto para la barra de estado (vacio si no hay nada que mostrar). */
void tarea_texto_barra(char *buf, size_t n);
/* Informe detallado (orden 't'). */
void tarea_texto_detalle(char *buf, size_t n);

/* Si la ultima tarea terminada reemplazo el archivo del editor, devuelve 1
 * una sola vez (el editor debe reabrir su descriptor y recargar). */
int  tarea_consumir_recarga(void);

/* Candado del archivo del editor (siempre try: nunca congela la UI).
 * Retornan 0 si se obtuvo; -1 y un mensaje si la tarea lo tiene ocupado.
 * Cada exito debe emparejarse con tarea_soltar_archivo(). */
int  tarea_intentar_escribir_archivo(char *msg, size_t msglen);
int  tarea_intentar_leer_archivo(char *msg, size_t msglen);
void tarea_soltar_archivo(void);
/* 1 si la tarea tiene tomado el archivo del editor (en cualquier modo). */
int  tarea_archivo_ocupado(void);

#endif
