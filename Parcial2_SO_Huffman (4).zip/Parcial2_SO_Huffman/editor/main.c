#include "editor.h"
#include "terminal.h"
#include "tarea.h"   // PARCIAL 2: tarea de compresion en segundo plano
#include <stdio.h> // Para constantes y tipos básicos estándar como NULL

/**
 * Punto de entrada del editor: activa el modo raw de la terminal,
 * inicializa el estado en memoria y entra al bucle principal
 * (dibujar pantalla -> leer una tecla -> repetir).
 */
int main(int argc, char *argv[]) {
    terminal_activar_modo_raw(); // el kernel deja de procesar el teclado por lineas

    // PARCIAL 2: pipe de notificacion (hilos -> UI) y manejadores de senales.
    if (tarea_inicializar() == -1) { perror("tarea_inicializar"); return 1; }

    EstadoEditor editor;
    const char* archivo_a_abrir = (argc >= 2) ? argv[1] : NULL;
    editor_inicializar(&editor, archivo_a_abrir);

    editor_pantalla_bienvenida(&editor);

    while (1) {
        editor_refrescar_pantalla(&editor); // dibuja el estado actual en pantalla
        editor_procesar_tecla(&editor);     // espera (poll) una tecla O un aviso de la tarea en 2do plano
    }

    editor_liberar(&editor);
    return 0;
}
