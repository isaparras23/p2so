#!/bin/bash
# ============================================================================
# Pruebas automatizadas - PARCIAL 2: Compresor Huffman concurrente integrado
# al editor (Sistemas Operativos SO2026B, EAFIT)
# ============================================================================
# Secciones:
#   1. Compilacion sin advertencias (-Wall -Wextra)
#   2. Correccion algoritmica: comprimir -> descomprimir -> cmp/md5sum, con
#      muchos tipos de archivo, numeros de hilos y tamanos de bloque
#   3. Manejo de errores: archivos corruptos, truncados, inexistentes...
#   4. Concurrencia: ThreadSanitizer, Helgrind y DRD (carreras / deadlocks)
#   5. Recursos: Valgrind memcheck (fugas de memoria) y descriptores
#   6. Integracion con el editor (pseudo-terminal): UI no bloqueada, barra de
#      progreso, candado del archivo, cancelacion, salida y senales
#   7. (opcional, con --bench) rendimiento con 1, 2, 4... hilos
#
# EAFIT_HUF_RETARDO_MS agrega una pausa artificial por bloque SOLO para que en
# las pruebas de integracion la tarea dure lo suficiente para interactuar
# con ella mientras corre. No cambia el algoritmo.
# ============================================================================

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DRIVER="$ROOT_DIR/tests/pty_driver"
EDITOR_BIN="$ROOT_DIR/editor/text_editor"
HUF="$ROOT_DIR/tools/huf"
TEST_DIR="$(mktemp -d /tmp/pruebas_p2_XXXXXX)"
export EAFIT_EDITOR_SIN_SPLASH=1

TOTAL=0
PASSED=0
OMITIDAS=0
# Una prueba que no se pudo correr NO cuenta como aprobada: se reporta aparte.
omitir() { OMITIDAS=$((OMITIDAS+$1)); echo "  [OMITIDA x$1] $2"; }
pass() { TOTAL=$((TOTAL+1)); PASSED=$((PASSED+1)); echo "  [OK] $1"; }
fail() { TOTAL=$((TOTAL+1)); echo "  [FALLO] $1"; }
check() { if eval "$2"; then pass "$1"; else fail "$1"; fi; }
titulo() { echo; echo "=================================================================="; echo " $1"; echo "=================================================================="; }
hay() { command -v "$1" >/dev/null 2>&1; }
# ThreadSanitizer falla con "unexpected memory mapping" en kernels que reparten la
# memoria con mucha aleatoriedad (ASLR), como el de GitHub Codespaces. Con
# "setarch -R" el programa corre con esa aleatoriedad apagada, y TSan funciona.
SIN_ASLR=""
if setarch "$(uname -m)" -R true 2>/dev/null; then SIN_ASLR="setarch $(uname -m) -R"; fi
# Cierra los descriptores heredados de la terminal (Codespaces deja uno abierto),
# para que Valgrind solo cuente los que abre nuestro programa.
cerrar_fds() { for f in /proc/$BASHPID/fd/*; do n=${f##*/}; [ "$n" -gt 2 ] 2>/dev/null && eval "exec $n>&-"; done 2>/dev/null; }

sin_temporales() { [ -z "$(ls "$1" | grep '\.tmp')" ]; }

# Lanza el editor en una pty con un guion (stdin). Variables extra: $EXTRA_ENV
editor_guion() {
    local archivo="$1"; shift
    timeout 120 "$DRIVER" env $EXTRA_ENV "$@" "$EDITOR_BIN" "$archivo"
}

if ! hay valgrind; then
  echo "AVISO: valgrind no esta instalado; 9 pruebas se omitiran (sudo apt install valgrind)."
fi
titulo "1. COMPILACION (-Wall -Wextra, -pthread)"
(cd "$ROOT_DIR/editor" && make clean >/dev/null 2>&1; make 2> "$TEST_DIR/warn_editor.txt" >/dev/null)
check "el editor compila" "[ -x '$EDITOR_BIN' ]"
check "el editor compila sin advertencias" "! grep -q warning '$TEST_DIR/warn_editor.txt'"
mkdir -p "$ROOT_DIR/tools"
rm -f "$HUF"; make -C "$ROOT_DIR" huf > "$TEST_DIR/warn_huf.txt" 2>&1
check "la herramienta huf compila sin advertencias" "[ -x '$HUF' ] && ! grep -q warning '$TEST_DIR/warn_huf.txt'"
gcc -Wall -Wextra -O2 -o "$DRIVER" "$ROOT_DIR/tests/pty_driver.c" -lutil
check "el driver de pruebas compila" "[ -x '$DRIVER' ]"

titulo "2. CORRECCION ALGORITMICA (comprimir -> descomprimir -> cmp)"
D="$TEST_DIR/datos"; mkdir -p "$D"
: > "$D/vacio"
printf 'a' > "$D/un_byte"
head -c 300000 /dev/zero | tr '\0' 'z' > "$D/un_solo_simbolo"
head -c 3000000 /dev/urandom > "$D/binario_aleatorio"
for i in $(seq 1 40000); do echo "Linea $i: El veloz murcielago hindu comia feliz cardillo y kiwi."; done > "$D/texto"
head -c 200000 /dev/urandom | base64 > "$D/base64"
head -c 65536 "$D/binario_aleatorio" > "$D/multiplo_exacto_de_bloque"
head -c 65537 "$D/binario_aleatorio" > "$D/bloque_mas_uno"
cat "$ROOT_DIR"/editor/*.c > "$D/codigo_fuente"
casos=0; malos=0
for f in "$D"/*; do
  for t in 1 2 3 4 8; do
    for b in 4096 65536 1048576; do
      casos=$((casos+1))
      if ! "$HUF" c "$f" "$TEST_DIR/x.huf" -t $t -b $b >/dev/null 2>&1 ||
         ! "$HUF" d "$TEST_DIR/x.huf" "$TEST_DIR/x.out" -t $t >/dev/null 2>&1 ||
         ! cmp -s "$f" "$TEST_DIR/x.out"; then
        malos=$((malos+1)); echo "      falla: $(basename "$f") hilos=$t bloque=$b"
      fi
    done
  done
done
check "$casos combinaciones (archivo x hilos x bloque) identicas al original" "[ $malos -eq 0 ]"
"$HUF" c "$D/texto" "$TEST_DIR/t.huf" -t 4 -b 65536 >/dev/null && "$HUF" d "$TEST_DIR/t.huf" "$TEST_DIR/t.out" -t 4 >/dev/null
M1=$(md5sum < "$D/texto"); M2=$(md5sum < "$TEST_DIR/t.out")
echo "      md5 original     : $M1"
echo "      md5 descomprimido: $M2"
check "md5sum identico (texto de 2.6 MB, 4 hilos)" "[ '$M1' = '$M2' ]"
"$HUF" c "$D/texto" "$TEST_DIR/t1.huf" -t 1 -b 65536 >/dev/null
check "la salida comprimida es identica con 1 y con 4 hilos (orden determinista)" "cmp -s '$TEST_DIR/t1.huf' '$TEST_DIR/t.huf'"
check "el texto efectivamente se comprime (< 60% del original)" "[ \$(stat -c%s '$TEST_DIR/t.huf') -lt \$(( \$(stat -c%s '$D/texto') * 60 / 100 )) ]"
# Base del curso: el Huffman SECUENCIAL del profesor (SO2026B) y el
# concurrente usan el MISMO arbol y los MISMOS codigos. Con un unico bloque,
# los bits de datos deben medir exactamente lo mismo; solo cambia la cabecera.
"$HUF" sc "$D/texto" "$TEST_DIR/prof.huf" >/dev/null && "$HUF" sd "$TEST_DIR/prof.huf" "$TEST_DIR/prof.out" >/dev/null
check "la version secuencial del profesor (base) recupera el archivo identico" "cmp -s '$D/texto' '$TEST_DIR/prof.out'"
"$HUF" c "$D/texto" "$TEST_DIR/uno.huf" -t 4 -b 4194304 >/dev/null
NSIM=$(od -An -v -tu1 "$D/texto" | tr -s ' ' '\n' | grep -v '^$' | sort -u | wc -l)
DATOS_PROF=$(( $(stat -c%s "$TEST_DIR/prof.huf") - 14 - 5 * NSIM ))
DATOS_CONC=$(( $(stat -c%s "$TEST_DIR/uno.huf") - 2072 - 16 ))
echo "      bytes de datos: profesor=$DATOS_PROF  concurrente=$DATOS_CONC"
check "mismo arbol que el codigo del profesor: los datos comprimidos miden lo mismo" "[ $DATOS_PROF -eq $DATOS_CONC ]"

titulo "3. MANEJO DE ERRORES"
cp "$TEST_DIR/t.huf" "$TEST_DIR/corrupto.huf"
printf '\xff\xff\xff\xff' | dd of="$TEST_DIR/corrupto.huf" bs=1 seek=500000 conv=notrunc 2>/dev/null
"$HUF" d "$TEST_DIR/corrupto.huf" "$TEST_DIR/corrupto.out" > "$TEST_DIR/e1.txt" 2>&1; rc=$?
check "bloque corrupto -> error de CRC32 (rc=$rc)" "[ $rc -ne 0 ] && grep -q 'CRC32\|corrupto' '$TEST_DIR/e1.txt'"
check "  ... y NO deja archivo de salida ni temporales" "[ ! -e '$TEST_DIR/corrupto.out' ] && sin_temporales '$TEST_DIR'"
head -c 100000 "$TEST_DIR/t.huf" > "$TEST_DIR/truncado.huf"
check "archivo .huf truncado -> error" "! '$HUF' d '$TEST_DIR/truncado.huf' '$TEST_DIR/tr.out' 2>/dev/null"
check "archivo que no es .huf -> error" "! '$HUF' d '$D/texto' '$TEST_DIR/no.out' 2>/dev/null"
check "origen inexistente -> error" "! '$HUF' c /no/existe '$TEST_DIR/n.huf' 2>/dev/null"
check "origen == destino -> rechazado" "! '$HUF' c '$D/texto' '$D/texto' 2>/dev/null && cmp -s '$D/texto' '$TEST_DIR/t.out'"
check "directorio destino inexistente -> error" "! '$HUF' c '$D/texto' /no/existe/x.huf 2>/dev/null"

titulo "4. CONCURRENCIA: carreras e interbloqueos (TSan / Helgrind / DRD)"
if gcc -g -O1 -fsanitize=thread -pthread -o "$TEST_DIR/huf_tsan" "$ROOT_DIR/tools/huf_cli.c" "$ROOT_DIR/editor/huffman_secuencial.c" "$ROOT_DIR/editor/huffman_concurrente.c" 2>/dev/null; then
  ok=1
  for t in 2 4 8; do
    TSAN_OPTIONS="exitcode=66" $SIN_ASLR "$TEST_DIR/huf_tsan" c "$D/texto" "$TEST_DIR/ts.huf" -t $t -b 32768 >/dev/null 2>"$TEST_DIR/tsan_c$t.txt" || ok=0
    TSAN_OPTIONS="exitcode=66" $SIN_ASLR "$TEST_DIR/huf_tsan" d "$TEST_DIR/ts.huf" "$TEST_DIR/ts.out" -t $t >/dev/null 2>"$TEST_DIR/tsan_d$t.txt" || ok=0
    cmp -s "$D/texto" "$TEST_DIR/ts.out" || ok=0
  done
  if grep -q "unexpected memory mapping" "$TEST_DIR"/tsan_*.txt; then
    omitir 1 "ThreadSanitizer no pudo arrancar en este kernel (ASLR) y setarch -R no esta disponible; NO es una carrera"
  else
    check "ThreadSanitizer: 0 carreras en compresion/descompresion (2, 4 y 8 hilos)" "[ $ok -eq 1 ] && ! grep -q 'WARNING: ThreadSanitizer' '$TEST_DIR'/tsan_*.txt"
  fi
else omitir 1 "ThreadSanitizer (gcc sin soporte -fsanitize=thread)"; fi
if hay valgrind; then
  gcc -g -O0 -pthread -o "$TEST_DIR/huf_g" "$ROOT_DIR/tools/huf_cli.c" "$ROOT_DIR/editor/huffman_secuencial.c" "$ROOT_DIR/editor/huffman_concurrente.c"
  head -c 400000 "$D/texto" > "$D/pequeno"
  valgrind --tool=helgrind --error-exitcode=9 -q "$TEST_DIR/huf_g" c "$D/pequeno" "$TEST_DIR/h.huf" -t 4 -b 16384 >/dev/null 2>"$TEST_DIR/helgrind.txt"; r1=$?
  valgrind --tool=helgrind --error-exitcode=9 -q "$TEST_DIR/huf_g" d "$TEST_DIR/h.huf" "$TEST_DIR/h.out" -t 4 >/dev/null 2>>"$TEST_DIR/helgrind.txt"; r2=$?
  check "Helgrind: sin carreras ni errores de orden de locks" "[ $r1 -eq 0 ] && [ $r2 -eq 0 ]"
  valgrind --tool=drd --error-exitcode=9 -q "$TEST_DIR/huf_g" c "$D/pequeno" "$TEST_DIR/d.huf" -t 4 -b 16384 >/dev/null 2>"$TEST_DIR/drd.txt"; r1=$?
  check "DRD: sin carreras" "[ $r1 -eq 0 ]"
else omitir 2 "Helgrind y DRD (valgrind no instalado)"; fi

titulo "5. RECURSOS: memoria, descriptores e hilos"
if hay valgrind; then
  ( cerrar_fds; valgrind --leak-check=full --show-leak-kinds=all --errors-for-leak-kinds=all --error-exitcode=9 -q --track-fds=yes \
    "$TEST_DIR/huf_g" c "$D/pequeno" "$TEST_DIR/m.huf" -t 4 -b 16384 >/dev/null 2>"$TEST_DIR/memcheck_c.txt" ); r1=$?
  valgrind --leak-check=full --show-leak-kinds=all --errors-for-leak-kinds=all --error-exitcode=9 -q \
    "$TEST_DIR/huf_g" d "$TEST_DIR/m.huf" "$TEST_DIR/m.out" -t 4 >/dev/null 2>"$TEST_DIR/memcheck_d.txt"; r2=$?
  valgrind --leak-check=full --errors-for-leak-kinds=all --error-exitcode=9 -q \
    "$TEST_DIR/huf_g" d "$TEST_DIR/corrupto.huf" "$TEST_DIR/m2.out" -t 4 >/dev/null 2>"$TEST_DIR/memcheck_e.txt"; r3=$?
  check "memcheck: 0 fugas y 0 errores al comprimir" "[ $r1 -eq 0 ]"
  check "memcheck: 0 fugas y 0 errores al descomprimir" "[ $r2 -eq 0 ]"
  check "memcheck: 0 fugas en la ruta de ERROR (archivo corrupto, hilos abortados)" "[ $r3 -eq 1 ] || [ $r3 -eq 0 ] && ! grep -q 'definitely lost\|ERROR SUMMARY: [1-9]' '$TEST_DIR/memcheck_e.txt'"
  check "descriptores: no queda ningun archivo abierto al terminar" "! grep -q 'Open file descriptor [3-9]' '$TEST_DIR/memcheck_c.txt'"
else omitir 4 "Valgrind memcheck: fugas y descriptores (valgrind no instalado)"; fi

titulo "6. INTEGRACION CON EL EDITOR (pseudo-terminal)"
# Archivo de ~1.3 MB en bloques de 64 KB (20 bloques) con una pausa de 300 ms
# por bloque y 2 hilos -> la tarea dura varios segundos y se puede interactuar.
E="$TEST_DIR/editor"; mkdir -p "$E"
for i in $(seq 1 20000); do echo "Linea $i: El veloz murcielago hindu comia feliz cardillo y kiwi."; done > "$E/original.txt"
ULT=$(( $(tail -1 "$E/original.txt" | wc -c) ))   # columna del cursor + 1 tras escribir una letra
export EAFIT_HUF_BLOQUE=65536 EAFIT_HUF_HILOS=2

# 6.1 ---------------------------------------------------------------------
cp "$E/original.txt" "$E/doc.txt"
EXTRA_ENV="EAFIT_HUF_RETARDO_MS=500" editor_guion "$E/doc.txt" > "$E/s1.out" 2> "$E/s1.err" <<GUION
TIMEOUT 10
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN z
WAITFOR Comprimiendo
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN t
WAITFOR Estado     : EN CURSO
WAITFOR Candado    : lectura
SENDLN
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN z otro.huf
WAITFOR Ya hay una tarea
SENDLN
CLEAR
SEND X
WAITFOR Col: $((ULT+1))
CLEAR
SENDCTRL s
WAITFOR Archivo ocupado
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "esta linea no debe llegar al disco"
WAITFOR Archivo ocupado
NOTEXPECT Linea anadida
SENDLN
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN p 2
WAITFOR Linea 2: Linea 2:
SENDLN
TIMEOUT 40
WAITFOR Compresion OK
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cerrando editor
GUION
r=$?
PROG=$(grep -ao 'Comprimiendo  *[0-9]*%' "$E/s1.out" | sort -u | wc -l)
check "6.1 la barra muestra el progreso en tiempo real ($PROG porcentajes distintos)" "[ $PROG -ge 5 ]"
check "6.1 durante la compresion: se edita (UI viva), Ctrl+S y 'a' se rechazan, 'p' se permite, 2a tarea rechazada" "[ $r -eq 0 ]"
[ $r -ne 0 ] && sed 's/^/      /' "$E/s1.err"
check "6.1 el archivo en disco no fue modificado durante la compresion" "cmp -s '$E/doc.txt' '$E/original.txt'"
"$HUF" d "$E/doc.txt.huf" "$E/rt.txt" >/dev/null 2>&1
check "6.1 el .huf generado por el editor se descomprime identico (md5)" "[ \"\$(md5sum < '$E/rt.txt')\" = \"\$(md5sum < '$E/original.txt')\" ]"
check "6.1 sin archivos temporales residuales" "sin_temporales '$E'"

# 6.2 ---------------------------------------------------------------------
# El editor tiene abierto doc.txt con contenido VIEJO; se descomprime el
# .huf ENCIMA de ese mismo archivo: candado de ESCRITURA + recarga final.
printf 'VERSION VIEJA linea 1\nVERSION VIEJA linea 2\n' > "$E/doc.txt"
EXTRA_ENV="EAFIT_HUF_RETARDO_MS=500" editor_guion "$E/doc.txt" > "$E/s2.out" 2> "$E/s2.err" <<GUION
TIMEOUT 10
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN u $E/doc.txt.huf
WAITFOR Descomprimiendo
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN p 1
WAITFOR Archivo ocupado
NOTEXPECT VERSION VIEJA linea 1
SENDLN
CLEAR
SENDCTRL s
WAITFOR Archivo ocupado
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN o $E/otro.txt
WAITFOR No se puede cambiar de archivo
SENDLN
TIMEOUT 40
WAITFOR Descompresion OK
WAITFOR recargado
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN p 1
WAITFOR Linea 1: Linea 1: El veloz
SENDLN
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cerrando editor
GUION
r=$?
check "6.2 descomprimir sobre el archivo abierto: lectura/guardado/cambio de archivo bloqueados" "[ $r -eq 0 ]"
[ $r -ne 0 ] && sed 's/^/      /' "$E/s2.err"
check "6.2 al terminar, el editor recarga y el archivo es identico al original (md5)" "[ \"\$(md5sum < '$E/doc.txt')\" = \"\$(md5sum < '$E/original.txt')\" ]"

# 6.3 ---------------------------------------------------------------------
cp "$E/original.txt" "$E/canc.txt"
EXTRA_ENV="EAFIT_HUF_RETARDO_MS=400" editor_guion "$E/canc.txt" > "$E/s3.out" 2> "$E/s3.err" <<GUION
TIMEOUT 10
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN z
WAITFOR Comprimiendo
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN c
WAITFOR Cancelacion solicitada
SENDLN
WAITFOR Tarea cancelada
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN a "linea tras cancelar"
WAITFOR Linea anadida correctamente
SENDLN
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cerrando editor
GUION
r=$?
check "6.3 cancelacion con 'c': la tarea se detiene y el archivo vuelve a ser editable" "[ $r -eq 0 ]"
check "6.3 la cancelacion no deja .huf parcial ni temporales" "[ ! -e '$E/canc.txt.huf' ] && sin_temporales '$E'"

# 6.4 ---------------------------------------------------------------------
cp "$E/original.txt" "$E/salir.txt"
t0=$(date +%s.%N)
EXTRA_ENV="EAFIT_HUF_RETARDO_MS=400" editor_guion "$E/salir.txt" > "$E/s4.out" 2> "$E/s4.err" <<GUION
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN z
WAITFOR Comprimiendo
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cancelando la tarea
WAITFOR Cerrando editor
GUION
r=$?
check "6.4 salir con 'q' en plena compresion: cancela y hace join de los hilos" "[ $r -eq 0 ]"
check "6.4 ... sin .huf parcial ni temporales y el original intacto" "[ ! -e '$E/salir.txt.huf' ] && sin_temporales '$E' && cmp -s '$E/salir.txt' '$E/original.txt'"

# 6.5 ---------------------------------------------------------------------
cp "$E/original.txt" "$E/senal.txt"
( sleep 2.5; pkill -TERM -f "text_editor $E/senal.txt" ) &
EXTRA_ENV="EAFIT_HUF_RETARDO_MS=400" editor_guion "$E/senal.txt" > "$E/s5.out" 2> "$E/s5.err" <<GUION
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN z
WAITFOR Comprimiendo
SLEEP 4
GUION
wait
sleep 0.5
check "6.5 SIGTERM durante la compresion: el proceso termina ordenadamente" "! pgrep -f 'text_editor $E/senal.txt' >/dev/null"
check "6.5 ... sin .huf parcial ni temporales" "[ ! -e '$E/senal.txt.huf' ] && sin_temporales '$E'"

# 6.6 ---------------------------------------------------------------------
if hay valgrind; then
  cp "$E/original.txt" "$E/vg.txt"
  EXTRA_ENV="EAFIT_HUF_RETARDO_MS=0" timeout 200 "$DRIVER" env valgrind --leak-check=full --errors-for-leak-kinds=definite \
     --log-file="$E/vg_editor.txt" "$EDITOR_BIN" "$E/vg.txt" > "$E/s6.out" 2>&1 <<GUION
TIMEOUT 60
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN z
WAITFOR Compresion OK
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN u $E/vg.txt.huf $E/vg2.txt
WAITFOR Descompresion OK
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cerrando editor
GUION
  check "6.6 editor completo bajo Valgrind: 0 bytes 'definitely lost'" "grep -q 'definitely lost: 0 bytes\|All heap blocks were freed' '$E/vg_editor.txt'"
  check "6.6 ... y 0 errores de memoria" "grep -q 'ERROR SUMMARY: 0 errors' '$E/vg_editor.txt'"
  check "6.6 ... y el resultado es identico al original" "cmp -s '$E/vg2.txt' '$E/original.txt'"
else omitir 3 "6.6 editor bajo Valgrind (valgrind no instalado)"; fi

# 6.7 ---------------------------------------------------------------------
if gcc -g -O1 -fsanitize=thread -pthread -D_GNU_SOURCE -std=gnu99 -o "$TEST_DIR/editor_tsan" \
     "$ROOT_DIR"/editor/{main,editor,terminal,comando,estructura,ordenes,huffman_secuencial,huffman_concurrente,tarea}.c 2>/dev/null; then
  cp "$E/original.txt" "$E/ts.txt"
  EXTRA_ENV="EAFIT_HUF_RETARDO_MS=400 EAFIT_HUF_HILOS=4 TSAN_OPTIONS=log_path=$E/tsan_editor"
  timeout 200 "$DRIVER" env $EXTRA_ENV $SIN_ASLR "$TEST_DIR/editor_tsan" "$E/ts.txt" > "$E/s7.out" 2> "$E/s7.err" <<GUION
TIMEOUT 15
WAITFOR Archivo:
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN z
WAITFOR Comprimiendo
CLEAR
SEND abc
SENDCTRL s
WAITFOR Archivo ocupado
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN p 1
WAITFOR Linea 1: Linea 1:
SENDLN
TIMEOUT 60
WAITFOR Compresion OK
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN u $E/ts.txt.huf
WAITFOR Descomprimiendo
CLEAR
SENDCTRL s
WAITFOR Archivo ocupado
WAITFOR Descompresion OK
WAITFOR recargado
CLEAR
SEND :
WAITFOR Orden (o/p/a/d/q
SENDLN q
WAITFOR Cerrando editor
GUION
  r=$?
  check "6.7 guion completo con el editor instrumentado (TSan)" "[ $r -eq 0 ]"
  [ $r -ne 0 ] && sed 's/^/      /' "$E/s7.err"
  check "6.7 editor completo con ThreadSanitizer (UI + tarea + pool): 0 carreras" "! ls '$E'/tsan_editor* >/dev/null 2>&1 && ! grep -q ThreadSanitizer '$E/s7.out'"
  check "6.7 ... y el archivo final es identico al original" "cmp -s '$E/ts.txt' '$E/original.txt'"
else omitir 3 "6.7 editor con ThreadSanitizer (gcc sin soporte -fsanitize=thread)"; fi

if [ "$1" = "--bench" ]; then
  titulo "7. RENDIMIENTO (informativo)"
  for i in $(seq 1 6); do cat "$D/texto"; done > "$D/grande"
  "$HUF" bench "$D/grande"
fi

if [ $OMITIDAS -gt 0 ]; then
  titulo "RESUMEN: $PASSED / $TOTAL pruebas pasaron, $OMITIDAS OMITIDAS ($((TOTAL+OMITIDAS)) en total)"
  echo "ATENCION: faltan herramientas. Instale valgrind (sudo apt install valgrind) y vuelva a"
  echo "correr el script: esas pruebas son la evidencia de 0 fugas y 0 interbloqueos."
else
  titulo "RESUMEN: $PASSED / $TOTAL pruebas pasaron"
fi
echo "Archivos de la prueba en: $TEST_DIR"
[ $PASSED -eq $TOTAL ] && [ $OMITIDAS -eq 0 ]
