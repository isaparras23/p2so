#!/bin/bash
# Evidencia de concurrencia y recursos para la sustentacion:
#   1) ThreadSanitizer  -> condiciones de carrera
#   2) Helgrind y DRD   -> carreras y errores de orden de locks (interbloqueos)
#   3) Valgrind memcheck-> fugas de memoria y descriptores abiertos
# Uso: bash demo/herramientas.sh   (desde la raiz; antes: bash demo/preparar_demo.sh)
RAIZ="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$RAIZ"
A="$RAIZ/demo/archivos"; T="$(mktemp -d)"
FUENTES="tools/huf_cli.c editor/huffman_secuencial.c editor/huffman_concurrente.c"
# -Wno-unused-result: evita avisos del codigo ORIGINAL del profesor (write sin revisar
# en su version secuencial, que no usa el modo concurrente).
F="-pthread -Wno-unused-result"
# ThreadSanitizer falla con "unexpected memory mapping" en kernels que reparten la
# memoria con mucha aleatoriedad (ASLR), como el de GitHub Codespaces. Con
# "setarch -R" el programa corre con esa aleatoriedad apagada, y TSan funciona.
SIN_ASLR=""
if setarch "$(uname -m)" -R true 2>/dev/null; then SIN_ASLR="setarch $(uname -m) -R"; fi
# Cierra los descriptores heredados de la terminal (Codespaces deja uno abierto),
# para que Valgrind solo cuente los que abre nuestro programa.
cerrar_fds() { for f in /proc/$BASHPID/fd/*; do n=${f##*/}; [ "$n" -gt 2 ] 2>/dev/null && eval "exec $n>&-"; done 2>/dev/null; }

head -c 400000 "$A/demo.txt" > "$T/peq.txt"

echo "================ 1. ThreadSanitizer (2, 4 y 8 hilos) ================"
gcc -g -O1 -fsanitize=thread $F -o "$T/huf_tsan" $FUENTES
for h in 2 4 8; do
  $SIN_ASLR "$T/huf_tsan" c "$A/demo.txt" "$T/t.huf" -t $h -b 32768 >/dev/null 2>"$T/tsan.txt"
  $SIN_ASLR "$T/huf_tsan" d "$T/t.huf" "$T/t.txt" -t $h >/dev/null 2>>"$T/tsan.txt"
  if grep -q "unexpected memory mapping" "$T/tsan.txt"; then
    echo "  $h hilos: ThreadSanitizer NO PUDO ARRANCAR en este kernel (ASLR). No es una carrera."
    echo "           Pruebe: sudo sysctl vm.mmap_rnd_bits=28  y vuelva a correr este script."
  elif grep -q "WARNING: ThreadSanitizer" "$T/tsan.txt"; then echo "  $h hilos: REPORTE DE CARRERA"; cat "$T/tsan.txt"
  elif cmp -s "$T/t.txt" "$A/demo.txt"; then echo "  $h hilos: 0 condiciones de carrera, archivo identico"
  else echo "  $h hilos: la prueba no termino bien:"; cat "$T/tsan.txt"; fi
  rm -f "$T/t.huf" "$T/t.txt"
done

gcc -g -O0 $F -o "$T/huf_g" $FUENTES
echo; echo "================ 2. Helgrind y DRD (Valgrind) ================"
valgrind --tool=helgrind "$T/huf_g" c "$T/peq.txt" "$T/h.huf" -t 4 -b 16384 2>&1 >/dev/null | grep "ERROR SUMMARY" | sed 's/^==[0-9]*==/  Helgrind (comprimir):/'
valgrind --tool=drd "$T/huf_g" d "$T/h.huf" "$T/h.txt" -t 4 2>&1 >/dev/null | grep "ERROR SUMMARY" | sed 's/^==[0-9]*==/  DRD (descomprimir):  /'

echo; echo "================ 3. Valgrind memcheck ================"
( cerrar_fds; valgrind --leak-check=full --show-leak-kinds=all --track-fds=yes "$T/huf_g" c "$T/peq.txt" "$T/m.huf" -t 4 -b 16384 2>"$T/mem.txt" >/dev/null )
grep -E "in use at exit|All heap blocks|ERROR SUMMARY|FILE DESCRIPTORS" "$T/mem.txt" | sed 's/^==[0-9]*==/  comprimir:  /'
valgrind --leak-check=full --show-leak-kinds=all "$T/huf_g" d "$A/corrupto.huf" "$T/c.txt" -t 4 2>"$T/mem2.txt" >/dev/null
echo "  (descomprimir un archivo DANADO: los hilos se abortan por error)"
grep -E "in use at exit|All heap blocks|ERROR SUMMARY" "$T/mem2.txt" | sed 's/^==[0-9]*==/  error:      /'
rm -rf "$T"
